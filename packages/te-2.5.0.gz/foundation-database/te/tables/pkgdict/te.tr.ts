<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>ARAging</name>
    <message>
        <source></source>
        <translation></translation>
    </message>
</context>
<context>
    <name>PurchaseOrder</name>
    <message>
        <source></source>
        <translation></translation>
    </message>
</context>
<context>
    <name>configureCRM</name>
    <message>
        <source>Project Labor And Overhead:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dspTimeExpenseHistory</name>
    <message>
        <source>Approved</source>
        <translation type="unfinished">Onaylandı</translation>
    </message>
    <message>
        <source>Closed</source>
        <translation type="unfinished">Kapatıldı</translation>
    </message>
    <message>
        <source>Project</source>
        <translation type="unfinished">Proje</translation>
    </message>
    <message>
        <source>Start Date</source>
        <translation type="unfinished">Başlangıç Tarihi</translation>
    </message>
    <message>
        <source>End Date</source>
        <translation type="unfinished">Bitiş Tarihi</translation>
    </message>
    <message>
        <source>Time</source>
        <translation type="unfinished">Zaman</translation>
    </message>
    <message>
        <source>Qty</source>
        <translation type="unfinished">Miktar</translation>
    </message>
    <message>
        <source>Employee</source>
        <translation type="unfinished">Personel</translation>
    </message>
    <message>
        <source>Customer Type</source>
        <translation type="unfinished">Müşteri Tipi</translation>
    </message>
    <message>
        <source>Customer</source>
        <translation type="unfinished">Müşteri</translation>
    </message>
    <message>
        <source>Print</source>
        <translation type="unfinished">Yazdır</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished">Kapat</translation>
    </message>
    <message>
        <source>Class Code</source>
        <translation type="unfinished">Sınıf Kodu</translation>
    </message>
    <message>
        <source>Customer Group</source>
        <translation type="unfinished">Müşteri Grubu</translation>
    </message>
    <message>
        <source>Item Group</source>
        <translation type="unfinished">Malzeme Grubu</translation>
    </message>
    <message>
        <source>View...</source>
        <translation type="unfinished">Göster...</translation>
    </message>
    <message>
        <source>Customer Type Pattern</source>
        <translation type="unfinished">Müşteri Türü Modeli</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished">Aç</translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished">Açıklama</translation>
    </message>
    <message>
        <source>Query</source>
        <translation type="unfinished">Sorgula</translation>
    </message>
    <message>
        <source>Cust. Name</source>
        <translation type="unfinished">Müşteri İsmi:</translation>
    </message>
    <message>
        <source>Item</source>
        <translation type="unfinished">Malzeme</translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished">Durumu</translation>
    </message>
    <message>
        <source>Sheet #</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Employee #</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Work Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Project#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Project Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Task#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Task Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cust.#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Billable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ext.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Expense</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Employee Group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Class Code Pattern</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Worksheet History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Worksheet Items</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>employee</name>
    <message>
        <source>Contractor</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>initMenu</name>
    <message>
        <source>Worksheets...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Worksheet History</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>item</name>
    <message>
        <source>Can not save item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You must select a Ledger Account or an expense account for Project Expense Items.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>project</name>
    <message>
        <source>Invalid Date</source>
        <translation type="unfinished">Geçersiz Tarih</translation>
    </message>
    <message>
        <source>Billing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gantt...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You must enter a valid Due Date</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>projectGantt</name>
    <message>
        <source>Close</source>
        <translation type="unfinished">Kapat</translation>
    </message>
    <message>
        <source>Project Gantt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+W</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>task</name>
    <message>
        <source>Billing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open Worksheets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add to Worksheet</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>taskList</name>
    <message>
        <source>Add To Worksheet...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open Worksheet...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Task List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sAddToLatestTESheet line %1: %2</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>tebilling</name>
    <message>
        <source>Billing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use specified billing rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use Specified item</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>tecustomer</name>
    <message>
        <source>Billing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use specified billing rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rate:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>teexpense</name>
    <message>
        <source>Account</source>
        <translation type="unfinished">Hesap</translation>
    </message>
    <message>
        <source>Expense Item Setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Allow use as Expense Item on Projects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Expense Category</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>timeExpenseSheet</name>
    <message>
        <source>View...</source>
        <translation type="unfinished">Göster...</translation>
    </message>
    <message>
        <source>Extended</source>
        <translation type="unfinished">Geniştetilmiş</translation>
    </message>
    <message>
        <source>Delete...</source>
        <translation type="unfinished">Sil...</translation>
    </message>
    <message>
        <source>Documents</source>
        <translation type="unfinished">Belgeler</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished">Aç</translation>
    </message>
    <message>
        <source>Closed</source>
        <translation type="unfinished">Kapatıldı</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">Hata</translation>
    </message>
    <message>
        <source>Hours</source>
        <translation type="unfinished">Saatler</translation>
    </message>
    <message>
        <source>Approved</source>
        <translation type="unfinished">Onaylandı</translation>
    </message>
    <message>
        <source>...</source>
        <translation type="unfinished">...</translation>
    </message>
    <message>
        <source>Site:</source>
        <translation type="unfinished">Site:</translation>
    </message>
    <message>
        <source>Employee:</source>
        <translation type="unfinished">Personel:</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation type="unfinished">Yeni</translation>
    </message>
    <message>
        <source>Notes</source>
        <translation type="unfinished">Notlar</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation type="unfinished">Sil</translation>
    </message>
    <message>
        <source>Print on Save</source>
        <translation type="unfinished">Kaydederken Yazdır</translation>
    </message>
    <message>
        <source>Total Cost</source>
        <translation type="unfinished">Toplam Maliyet</translation>
    </message>
    <message>
        <source>Line #</source>
        <translation type="unfinished">Satır No</translation>
    </message>
    <message>
        <source>Cust. Name</source>
        <translation type="unfinished">Müşteri İsmi:</translation>
    </message>
    <message>
        <source>Item</source>
        <translation type="unfinished">Malzeme</translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished">Açıklama</translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sheet Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Work Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Project#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Project Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Task#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Task Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cust.#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Expense</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Billable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>timeExpenseSheet.js exception: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>set exception: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>populateMenu exception: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure you want to delete this line?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>deleteItem exception: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>newItem exception: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>editItem exception: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>viewItem exception: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>openItem exception: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>accepted exception: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Employee Required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Site Required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Week Ending Date Required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Worksheet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>handleNewButton exception: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>populate exception: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hourly Cost</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Time</source>
        <translation type="unfinished">Zaman</translation>
    </message>
    <message>
        <source>fillList exception: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>printSheet exception: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete Worksheet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;Are you sure you want to cancel this Worksheet and discard all your changes?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>close exception: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sheet #:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>S&amp;heet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Week of Date:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>timeExpenseSheetItem</name>
    <message>
        <source>Employee:</source>
        <translation type="unfinished">Personel:</translation>
    </message>
    <message>
        <source>Time</source>
        <translation type="unfinished">Zaman</translation>
    </message>
    <message>
        <source>Total:</source>
        <translation type="unfinished">Toplam:</translation>
    </message>
    <message>
        <source>New</source>
        <translation type="unfinished">Yeni</translation>
    </message>
    <message>
        <source>Default</source>
        <translation type="unfinished">Varsayılan</translation>
    </message>
    <message>
        <source>Project #:</source>
        <translation type="unfinished">Proje #:</translation>
    </message>
    <message>
        <source>Item Required</source>
        <translation type="unfinished">Malzeme İhtiyacı</translation>
    </message>
    <message>
        <source>Task</source>
        <translation type="unfinished">Görev</translation>
    </message>
    <message>
        <source>Summary</source>
        <translation type="unfinished">Özet</translation>
    </message>
    <message>
        <source>Total Cost:</source>
        <translation type="unfinished">Toplam Maliyet:</translation>
    </message>
    <message>
        <source>Employee</source>
        <translation type="unfinished">Personel</translation>
    </message>
    <message>
        <source>Hours</source>
        <translation type="unfinished">Saatler</translation>
    </message>
    <message>
        <source>Notes</source>
        <translation type="unfinished">Notlar</translation>
    </message>
    <message>
        <source>Prev</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No task found. A default task will be added</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>task</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Update Rate?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;Would you like to update the existing rate?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Work Date Required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Project Required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Task Required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Billing of negative amounts is not supported</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Processing Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The system only supports vouchering positive expense quantities and amounts.  Do you want to save anyway?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hours:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qty:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unit Cost:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The Employee is not a Vendor, this expense cannot be vouchered.  Do you want to continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unsaved Changed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;You have made some changes which have not yet been saved!&lt;/p&gt;&lt;p&gt;Would you like to save them now?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;You have made some changes which have not yet been saved!
Would you like to save them now?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Expense</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Worksheet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Worksheet:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Line #:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Week of:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Work Date:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Task:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>  Cust. PO#:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Billable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>timedtl_rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Prepaid (not reimbursable)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hourly Cost:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Planned Hours:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Planned Expense:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Actual Hours:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Actual Expense:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Day Total:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Worksheet Total:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You must enter time on the Work Sheet</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>timeExpenseSheets</name>
    <message>
        <source>Yes</source>
        <translation type="unfinished">Evet</translation>
    </message>
    <message>
        <source>New</source>
        <translation type="unfinished">Yeni</translation>
    </message>
    <message>
        <source>Latest</source>
        <translation type="unfinished">En Geç</translation>
    </message>
    <message>
        <source>No</source>
        <translation type="unfinished">Hayır</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished">Sil</translation>
    </message>
    <message>
        <source>Process</source>
        <translation type="unfinished">İşlem</translation>
    </message>
    <message>
        <source>Query</source>
        <translation type="unfinished">Sorgula</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished">Kapat</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished">Aç</translation>
    </message>
    <message>
        <source>Invoice</source>
        <translation type="unfinished">Fatura</translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished">Durumu</translation>
    </message>
    <message>
        <source>Closed</source>
        <translation type="unfinished">Kapatıldı</translation>
    </message>
    <message>
        <source>Print</source>
        <translation type="unfinished">Yazdır</translation>
    </message>
    <message>
        <source>Invoiced</source>
        <translation type="unfinished">Faturalanan</translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished">Tarih</translation>
    </message>
    <message>
        <source>Earliest</source>
        <translation type="unfinished">En Erken</translation>
    </message>
    <message>
        <source>Approved</source>
        <translation type="unfinished">Onaylandı</translation>
    </message>
    <message>
        <source>Employee</source>
        <translation type="unfinished">Personel</translation>
    </message>
    <message>
        <source>Employees</source>
        <translation type="unfinished">Çalışanlar</translation>
    </message>
    <message>
        <source>Sheet#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To Invoice</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To Voucher</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vouchered</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Posted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View...</source>
        <translation type="unfinished">Göster...</translation>
    </message>
    <message>
        <source>Approve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unapprove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Voucher</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Post Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Setup Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No Labor and Overhead Account defined in CRM Setup.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Post Time Sheet for </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> to Project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This action can not be undone.  Are you sure you want to delete this Worksheet?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>N/A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>It appears that your current user isn&apos;t an active employee.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Permissions Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You do not have permissions to maintain Worksheet entries</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Worksheets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Selected:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Week of</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>When Processing:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Process Approved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Approve All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+R</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+P</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Notes</source>
        <translation type="unfinished">Notlar</translation>
    </message>
    <message>
        <source>Hours</source>
        <translation type="unfinished">Saatler</translation>
    </message>
    <message>
        <source>Reopen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure you want to close this Worksheet?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure you want to reopen this Worksheet?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Direct Reports</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>xtte</name>
    <message>
        <source>Database Error</source>
        <translation type="unfinished">Veritabanı Hatası</translation>
    </message>
</context>
</TS>
