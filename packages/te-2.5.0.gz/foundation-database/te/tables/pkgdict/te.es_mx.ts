<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>configureCRM</name>
    <message>
        <source>Project Labor And Overhead:</source>
        <translation type="unfinished">M. Obra e Indirectos de Proyectos:</translation>
    </message>
</context>
<context>
    <name>dspTimeExpenseHistory</name>
    <message>
        <source>Start Date</source>
        <translation type="unfinished">Fecha Inicial</translation>
    </message>
    <message>
        <source>Billable</source>
        <translation type="unfinished">Facturable</translation>
    </message>
    <message>
        <source>Approved</source>
        <translation type="unfinished">Aprobado</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished">Abierto</translation>
    </message>
    <message>
        <source>View...</source>
        <translation type="unfinished">Ver...</translation>
    </message>
    <message>
        <source>Project Name</source>
        <translation type="unfinished">Nombre Proyecto</translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished">Estado</translation>
    </message>
    <message>
        <source>Work Date</source>
        <translation type="unfinished">Fecha Trabajo</translation>
    </message>
    <message>
        <source>Sheet #</source>
        <translation type="unfinished">Hoja #</translation>
    </message>
    <message>
        <source>Project</source>
        <translation type="unfinished">Proyecto</translation>
    </message>
    <message>
        <source>Expense</source>
        <translation type="unfinished">Gasto</translation>
    </message>
    <message>
        <source>Time</source>
        <translation type="unfinished">Tiempo</translation>
    </message>
    <message>
        <source>Ext.</source>
        <translation type="unfinished">Imp.</translation>
    </message>
    <message>
        <source>Cust.#</source>
        <translation type="unfinished">Client.#</translation>
    </message>
    <message>
        <source>Task Name</source>
        <translation type="unfinished">Nombre de Tarea</translation>
    </message>
    <message>
        <source>PO</source>
        <translation type="unfinished">OC</translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished">Descripción</translation>
    </message>
    <message>
        <source>Employee Group</source>
        <translation type="unfinished">Grupo Empleados</translation>
    </message>
    <message>
        <source>End Date</source>
        <translation type="unfinished">Fecha Final</translation>
    </message>
    <message>
        <source>Employee</source>
        <translation type="unfinished">Empleado</translation>
    </message>
    <message>
        <source>Customer</source>
        <translation type="unfinished">Cliente</translation>
    </message>
    <message>
        <source>Customer Type Pattern</source>
        <translation type="unfinished">Tipo Cliente Comienza con</translation>
    </message>
    <message>
        <source>Customer Type</source>
        <translation type="unfinished">Tipo de Cliente</translation>
    </message>
    <message>
        <source>Class Code Pattern</source>
        <translation type="unfinished">Cód. Clase Comienza con</translation>
    </message>
    <message>
        <source>Edit...</source>
        <translation type="unfinished">Editar...</translation>
    </message>
    <message>
        <source>Item Group</source>
        <translation type="unfinished">Grupo de Productos</translation>
    </message>
    <message>
        <source>Customer Group</source>
        <translation type="unfinished">Grupo de Clientes</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished">Cerrar</translation>
    </message>
    <message>
        <source>Print</source>
        <translation type="unfinished">Imprimir</translation>
    </message>
    <message>
        <source>Query</source>
        <translation type="unfinished">Consultar</translation>
    </message>
    <message>
        <source>Employee #</source>
        <translation type="unfinished">Empleado #</translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished">Tipo</translation>
    </message>
    <message>
        <source>Project#</source>
        <translation type="unfinished">Proyecto#</translation>
    </message>
    <message>
        <source>Cust. Name</source>
        <translation type="unfinished">Nombre Clien.</translation>
    </message>
    <message>
        <source>Item</source>
        <translation type="unfinished">Producto</translation>
    </message>
    <message>
        <source>Qty</source>
        <translation type="unfinished">Cant.</translation>
    </message>
    <message>
        <source>Class Code</source>
        <translation type="unfinished">Código de Clase</translation>
    </message>
    <message>
        <source>Closed</source>
        <translation type="unfinished">Cerrado</translation>
    </message>
    <message>
        <source>Task#</source>
        <translation type="unfinished">Tarea#</translation>
    </message>
    <message>
        <source>Worksheet History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Worksheet Items</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>employee</name>
    <message>
        <source>Contractor</source>
        <translation type="unfinished">Contratista</translation>
    </message>
</context>
<context>
    <name>initMenu</name>
    <message>
        <source>Worksheets...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Worksheet History</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>item</name>
    <message>
        <source>Can not save item</source>
        <translation type="unfinished">No se pudo guardar el producto</translation>
    </message>
    <message>
        <source>You must select a Ledger Account or an expense account for Project Expense Items.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>project</name>
    <message>
        <source>You must enter a valid Due Date</source>
        <translation type="unfinished">Debe capturar una Fecha Limite válida</translation>
    </message>
    <message>
        <source>Invalid Date</source>
        <translation type="unfinished">Fecha Inválida</translation>
    </message>
    <message>
        <source>Gantt...</source>
        <translation type="unfinished">Gantt...</translation>
    </message>
    <message>
        <source>Billing</source>
        <translation type="unfinished">Facturación</translation>
    </message>
</context>
<context>
    <name>projectGantt</name>
    <message>
        <source>Ctrl+W</source>
        <translation type="unfinished">Ctrl+W</translation>
    </message>
    <message>
        <source>Project Gantt</source>
        <translation type="unfinished">Gantt del Proyecto</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished">Cerrar</translation>
    </message>
</context>
<context>
    <name>task</name>
    <message>
        <source>Billing</source>
        <translation type="unfinished">Facturación</translation>
    </message>
    <message>
        <source>Open Worksheets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add to Worksheet</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>taskList</name>
    <message>
        <source>Add To Worksheet...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open Worksheet...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Task List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>sAddToLatestTESheet line %1: %2</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>tebilling</name>
    <message>
        <source>Billing</source>
        <translation type="unfinished">Facturación</translation>
    </message>
    <message>
        <source>Rate:</source>
        <translation type="unfinished">Tarifa:</translation>
    </message>
    <message>
        <source>Use specified billing rate</source>
        <translation type="unfinished">Usar tarifa específicada</translation>
    </message>
    <message>
        <source>Use Specified item</source>
        <translation type="unfinished">Usar Producto especificado</translation>
    </message>
</context>
<context>
    <name>tecustomer</name>
    <message>
        <source>Billing</source>
        <translation type="unfinished">Facturación</translation>
    </message>
    <message>
        <source>Use specified billing rate</source>
        <translation type="unfinished">Usar tarifa específicada</translation>
    </message>
    <message>
        <source>Rate:</source>
        <translation type="unfinished">Tarifa:</translation>
    </message>
</context>
<context>
    <name>teexpense</name>
    <message>
        <source>Account</source>
        <translation type="unfinished">Cuenta</translation>
    </message>
    <message>
        <source>Expense Item Setup</source>
        <translation type="unfinished">Gasto de Preparación</translation>
    </message>
    <message>
        <source>Expense Category</source>
        <translation type="unfinished">Categoría de Gasto</translation>
    </message>
    <message>
        <source>Allow use as Expense Item on Projects</source>
        <translation type="unfinished">Permitir usar como Gasto en Proyectos</translation>
    </message>
</context>
<context>
    <name>timeExpenseSheet</name>
    <message>
        <source>PO</source>
        <translation type="unfinished">OC</translation>
    </message>
    <message>
        <source>Documents</source>
        <translation type="unfinished">Documentos</translation>
    </message>
    <message>
        <source>handleNewButton exception: </source>
        <translation type="unfinished">excepción handleNewButton:</translation>
    </message>
    <message>
        <source>Project Name</source>
        <translation type="unfinished">Nombre Proyecto</translation>
    </message>
    <message>
        <source>viewItem exception: </source>
        <translation type="unfinished">excepción viewItem:</translation>
    </message>
    <message>
        <source>Project#</source>
        <translation type="unfinished">Proyecto #</translation>
    </message>
    <message>
        <source>Line #</source>
        <translation type="unfinished">Partida #</translation>
    </message>
    <message>
        <source>populateMenu exception: </source>
        <translation type="unfinished">excepción populateMenu:</translation>
    </message>
    <message>
        <source>deleteItem exception: </source>
        <translation type="unfinished">excepción deleteItem:</translation>
    </message>
    <message>
        <source>Sheet Date</source>
        <translation type="unfinished">Fecha Hoja:</translation>
    </message>
    <message>
        <source>Hourly Cost</source>
        <translation type="unfinished">Costo x Hora</translation>
    </message>
    <message>
        <source>Total Cost</source>
        <translation type="unfinished">Costo Total</translation>
    </message>
    <message>
        <source>Cust.#</source>
        <translation type="unfinished">Cliente #</translation>
    </message>
    <message>
        <source>newItem exception: </source>
        <translation type="unfinished">excepción newItem:</translation>
    </message>
    <message>
        <source>Task Name</source>
        <translation type="unfinished">Nombre de Tarea</translation>
    </message>
    <message>
        <source>set exception: </source>
        <translation type="unfinished">excepción set:</translation>
    </message>
    <message>
        <source>Item</source>
        <translation type="unfinished">Producto</translation>
    </message>
    <message>
        <source>openItem exception: </source>
        <translation type="unfinished">excepción openItem:</translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished">Descripción</translation>
    </message>
    <message>
        <source>printSheet exception: </source>
        <translation type="unfinished">excepción printSheet:</translation>
    </message>
    <message>
        <source>Delete...</source>
        <translation type="unfinished">Eliminar...</translation>
    </message>
    <message>
        <source>close exception: </source>
        <translation type="unfinished">excepción close:</translation>
    </message>
    <message>
        <source>View...</source>
        <translation type="unfinished">Ver...</translation>
    </message>
    <message>
        <source>accepted exception: </source>
        <translation type="unfinished">excepción accepted:</translation>
    </message>
    <message>
        <source>fillList exception: </source>
        <translation type="unfinished">excepción fillList:</translation>
    </message>
    <message>
        <source>Billable</source>
        <translation type="unfinished">Facturable</translation>
    </message>
    <message>
        <source>timeExpenseSheet.js exception: </source>
        <translation type="unfinished">excepción timeExpenseSheet.js:</translation>
    </message>
    <message>
        <source>editItem exception: </source>
        <translation type="unfinished">excepción editarProd:</translation>
    </message>
    <message>
        <source>Edit...</source>
        <translation type="unfinished">Editar...</translation>
    </message>
    <message>
        <source>populate exception: </source>
        <translation type="unfinished">excepción populate:</translation>
    </message>
    <message>
        <source>Extended</source>
        <translation type="unfinished">Importe</translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished">Tipo</translation>
    </message>
    <message>
        <source>Are you sure you want to delete this line?</source>
        <translation type="unfinished">¿Está seguro que desea eliminar la línea?</translation>
    </message>
    <message>
        <source>Site Required</source>
        <translation type="unfinished">Requiere Sitio</translation>
    </message>
    <message>
        <source>Employee Required</source>
        <translation type="unfinished">Se requiere el empleado</translation>
    </message>
    <message>
        <source>Week Ending Date Required</source>
        <translation type="unfinished">Fecha de final de semana requerida</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished">Abierto</translation>
    </message>
    <message>
        <source>Time</source>
        <translation type="unfinished">Tiempo</translation>
    </message>
    <message>
        <source>Closed</source>
        <translation type="unfinished">Cerrado</translation>
    </message>
    <message>
        <source>Expense</source>
        <translation type="unfinished">Gasto</translation>
    </message>
    <message>
        <source>Notes</source>
        <translation type="unfinished">Notas</translation>
    </message>
    <message>
        <source>S&amp;heet</source>
        <translation type="unfinished">Hoja</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation type="unfinished">Eli&amp;amp;minar</translation>
    </message>
    <message>
        <source>Work Date</source>
        <translation type="unfinished">Fecha trabajos</translation>
    </message>
    <message>
        <source>Task#</source>
        <translation type="unfinished">Tarea #</translation>
    </message>
    <message>
        <source>Cust. Name</source>
        <translation type="unfinished">Nombre Clien.</translation>
    </message>
    <message>
        <source>Rate</source>
        <translation type="unfinished">Tarifa</translation>
    </message>
    <message>
        <source>Hours</source>
        <translation type="unfinished">Horas</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <source>Approved</source>
        <translation type="unfinished">Aprobado</translation>
    </message>
    <message>
        <source>Sheet #:</source>
        <translation type="unfinished">Hoja #:</translation>
    </message>
    <message>
        <source>...</source>
        <translation type="unfinished">...</translation>
    </message>
    <message>
        <source>Week of Date:</source>
        <translation type="unfinished">Semana del:</translation>
    </message>
    <message>
        <source>Site:</source>
        <translation type="unfinished">Sitio:</translation>
    </message>
    <message>
        <source>Employee:</source>
        <translation type="unfinished">Empleado:</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation type="unfinished">&amp;amp;Nuevo</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation type="unfinished">Editar</translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation type="unfinished">&amp;amp;Ver</translation>
    </message>
    <message>
        <source>Print on Save</source>
        <translation type="unfinished">Imprimir al Guardar</translation>
    </message>
    <message>
        <source>Worksheet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete Worksheet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;Are you sure you want to cancel this Worksheet and discard all your changes?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>timeExpenseSheetItem</name>
    <message>
        <source>Update Rate?</source>
        <translation type="unfinished">¿Actualizar Tarifa?</translation>
    </message>
    <message>
        <source>&lt;p&gt;You have made some changes which have not yet been saved!
Would you like to save them now?</source>
        <translation type="unfinished">Usted ha hecho algunos cambios que no han sido guardados todavía. ¿Desea guardarlos ahora?</translation>
    </message>
    <message>
        <source>The Employee is not a Vendor, this expense cannot be vouchered.  Do you want to continue?</source>
        <translation type="unfinished">&lt;p&gt;El Empleado no es un vendedor, este gasto no puede ser facturado. ¿Desea continuar?</translation>
    </message>
    <message>
        <source>Unit Cost:</source>
        <translation type="unfinished">Costo Unitario:</translation>
    </message>
    <message>
        <source>Total Cost:</source>
        <translation type="unfinished">Costo Total:</translation>
    </message>
    <message>
        <source>Prev</source>
        <translation type="unfinished">Previo</translation>
    </message>
    <message>
        <source>&lt;p&gt;You have made some changes which have not yet been saved!&lt;/p&gt;&lt;p&gt;Would you like to save them now?</source>
        <translation type="unfinished">Ha realizado cambios que no han sido guardados aún!&lt;br&gt;¿Desea guardarlos ahora?</translation>
    </message>
    <message>
        <source>New</source>
        <translation type="unfinished">Nuevo</translation>
    </message>
    <message>
        <source>Hourly Cost:</source>
        <translation type="unfinished">Costo x Hora:</translation>
    </message>
    <message>
        <source>&lt;p&gt;Would you like to update the existing rate?</source>
        <translation type="unfinished">¿Le gustaría actualizar la terifa existente?</translation>
    </message>
    <message>
        <source>Next</source>
        <translation type="unfinished">Siguiente</translation>
    </message>
    <message>
        <source>No task found. A default task will be added</source>
        <translation type="unfinished">Ninguna Tarea fue encontrada. Una Tarea predeterminada será agregada</translation>
    </message>
    <message>
        <source>task</source>
        <translation type="unfinished">tarea</translation>
    </message>
    <message>
        <source>Processing Error</source>
        <translation type="unfinished">Error al procesar</translation>
    </message>
    <message>
        <source>Work Date Required</source>
        <translation type="unfinished">Fecha de Trabajo requerida</translation>
    </message>
    <message>
        <source>Project Required</source>
        <translation type="unfinished">Proyecto Requerido</translation>
    </message>
    <message>
        <source>Task Required</source>
        <translation type="unfinished">Tarea Requerida</translation>
    </message>
    <message>
        <source>Billing of negative amounts is not supported</source>
        <translation type="unfinished">Facturación de importes negativos no está soportado</translation>
    </message>
    <message>
        <source>Rate:</source>
        <translation type="unfinished">Tarifa:</translation>
    </message>
    <message>
        <source>Hours:</source>
        <translation type="unfinished">Horas:</translation>
    </message>
    <message>
        <source>Unsaved Changed</source>
        <translation type="unfinished">Cambios no guardados</translation>
    </message>
    <message>
        <source>Expense</source>
        <translation type="unfinished">Gasto</translation>
    </message>
    <message>
        <source>Planned Hours:</source>
        <translation type="unfinished">Horas Planeadas:</translation>
    </message>
    <message>
        <source>Time</source>
        <translation type="unfinished">Tiempo</translation>
    </message>
    <message>
        <source>Task</source>
        <translation type="unfinished">Tarea</translation>
    </message>
    <message>
        <source>Project #:</source>
        <translation type="unfinished">Proyecto #:</translation>
    </message>
    <message>
        <source>Work Date:</source>
        <translation type="unfinished">Fecha Trabajo:</translation>
    </message>
    <message>
        <source>Prepaid (not reimbursable)</source>
        <translation type="unfinished">Prepagado (no rembolsable)</translation>
    </message>
    <message>
        <source>Billable</source>
        <translation type="unfinished">Facturable</translation>
    </message>
    <message>
        <source>Total:</source>
        <translation type="unfinished">Total:</translation>
    </message>
    <message>
        <source>Task:</source>
        <translation type="unfinished">Tarea:</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation type="unfinished">Tipo:</translation>
    </message>
    <message>
        <source>Day Total:</source>
        <translation type="unfinished">Total Dia:</translation>
    </message>
    <message>
        <source>Planned Expense:</source>
        <translation type="unfinished">Gastos Planeados:</translation>
    </message>
    <message>
        <source>Employee</source>
        <translation type="unfinished">Empleado</translation>
    </message>
    <message>
        <source>Actual Expense:</source>
        <translation type="unfinished">Gasto Actual:</translation>
    </message>
    <message>
        <source>Actual Hours:</source>
        <translation type="unfinished">Horas Actuales:</translation>
    </message>
    <message>
        <source>Notes</source>
        <translation type="unfinished">Notas</translation>
    </message>
    <message>
        <source>Default</source>
        <translation type="unfinished">Preferencia</translation>
    </message>
    <message>
        <source>Qty:</source>
        <translation type="unfinished">Cant:</translation>
    </message>
    <message>
        <source>  Cust. PO#:</source>
        <translation type="unfinished">OC Cliente#:</translation>
    </message>
    <message>
        <source>Employee:</source>
        <translation type="unfinished">Empleado:</translation>
    </message>
    <message>
        <source>timedtl_rate</source>
        <translation type="unfinished">timedtl_rate</translation>
    </message>
    <message>
        <source>Week of:</source>
        <translation type="unfinished">Semana del:</translation>
    </message>
    <message>
        <source>Summary</source>
        <translation type="unfinished">Resumen</translation>
    </message>
    <message>
        <source>Hours</source>
        <translation type="unfinished">Horas</translation>
    </message>
    <message>
        <source>Line #:</source>
        <translation type="unfinished">Partida #:</translation>
    </message>
    <message>
        <source>Item Required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The system only supports vouchering positive expense quantities and amounts.  Do you want to save anyway?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Worksheet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Worksheet:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Worksheet Total:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You must enter time on the Work Sheet</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>timeExpenseSheets</name>
    <message>
        <source>To Voucher</source>
        <translation type="unfinished">A Fact Prov</translation>
    </message>
    <message>
        <source>Approve</source>
        <translation type="unfinished">Autorizar</translation>
    </message>
    <message>
        <source>To Invoice</source>
        <translation type="unfinished">A Factura</translation>
    </message>
    <message>
        <source>View...</source>
        <translation type="unfinished">Ver...</translation>
    </message>
    <message>
        <source>Posted</source>
        <translation type="unfinished">Asentado</translation>
    </message>
    <message>
        <source>Sheet#</source>
        <translation type="unfinished">Hoja #</translation>
    </message>
    <message>
        <source>Vouchered</source>
        <translation type="unfinished">Facturado</translation>
    </message>
    <message>
        <source>No Labor and Overhead Account defined in CRM Setup.</source>
        <translation type="unfinished">No se ha definido la cuenta de Mano de Obra y Costos fijos en la Configuración del CRM</translation>
    </message>
    <message>
        <source>Invoice</source>
        <translation type="unfinished">Factura</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished">Cerrar</translation>
    </message>
    <message>
        <source>Setup Error</source>
        <translation type="unfinished">Error de Configuración</translation>
    </message>
    <message>
        <source> to Project</source>
        <translation type="unfinished">al Proyecto</translation>
    </message>
    <message>
        <source>Post Time Sheet for </source>
        <translation type="unfinished">Asentar Hoja de Tiempos para</translation>
    </message>
    <message>
        <source>Closed</source>
        <translation type="unfinished">Cerrado</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="unfinished">Si</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished">Abierto</translation>
    </message>
    <message>
        <source>It appears that your current user isn&apos;t an active employee.</source>
        <translation type="unfinished">Aparentemente el usuario actual no es un empleado activo.</translation>
    </message>
    <message>
        <source>No</source>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <source>Permissions Error</source>
        <translation type="unfinished">Error de permisos</translation>
    </message>
    <message>
        <source>Process</source>
        <translation type="unfinished">Proceso</translation>
    </message>
    <message>
        <source>Week of</source>
        <translation type="unfinished">Semana del</translation>
    </message>
    <message>
        <source>All</source>
        <translation type="unfinished">Todo</translation>
    </message>
    <message>
        <source>When Processing:</source>
        <translation type="unfinished">Cuando este Procesando:</translation>
    </message>
    <message>
        <source>Ctrl+N</source>
        <translation type="unfinished">Ctrl+N</translation>
    </message>
    <message>
        <source>Process Approved</source>
        <translation type="unfinished">Proceso Autorizado</translation>
    </message>
    <message>
        <source>Query</source>
        <translation type="unfinished">Consultar</translation>
    </message>
    <message>
        <source>Ctrl+P</source>
        <translation type="unfinished">Ctrl+P</translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished">Fecha</translation>
    </message>
    <message>
        <source>Employee</source>
        <translation type="unfinished">Empleado</translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished">Estado</translation>
    </message>
    <message>
        <source>Invoiced</source>
        <translation type="unfinished">Facturado</translation>
    </message>
    <message>
        <source>Print</source>
        <translation type="unfinished">Imprimir</translation>
    </message>
    <message>
        <source>Edit...</source>
        <translation type="unfinished">Editar...</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <source>Unapprove</source>
        <translation type="unfinished">No autorizar</translation>
    </message>
    <message>
        <source>Voucher</source>
        <translation type="unfinished">Factura</translation>
    </message>
    <message>
        <source>Post Time</source>
        <translation type="unfinished">Asentar Tiempos</translation>
    </message>
    <message>
        <source>Approved</source>
        <translation type="unfinished">Aprobado</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation type="unfinished">N/D</translation>
    </message>
    <message>
        <source>Employees</source>
        <translation type="unfinished">Empleados</translation>
    </message>
    <message>
        <source>Selected:</source>
        <translation type="unfinished">Seleccionado:</translation>
    </message>
    <message>
        <source>New</source>
        <translation type="unfinished">Nuevo</translation>
    </message>
    <message>
        <source>Ctrl+W</source>
        <translation type="unfinished">Ctrl+W</translation>
    </message>
    <message>
        <source>Approve All</source>
        <translation type="unfinished">Autorizar Todo</translation>
    </message>
    <message>
        <source>Ctrl+R</source>
        <translation type="unfinished">Ctrl+R</translation>
    </message>
    <message>
        <source>This action can not be undone.  Are you sure you want to delete this Worksheet?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You do not have permissions to maintain Worksheet entries</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Earliest</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Latest</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Worksheets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Notes</source>
        <translation type="unfinished">Notas</translation>
    </message>
    <message>
        <source>Hours</source>
        <translation type="unfinished">Horas</translation>
    </message>
    <message>
        <source>Reopen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure you want to close this Worksheet?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure you want to reopen this Worksheet?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Direct Reports</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>xtte</name>
    <message>
        <source>Database Error</source>
        <translation type="unfinished">Error de Base de Datos</translation>
    </message>
</context>
</TS>
