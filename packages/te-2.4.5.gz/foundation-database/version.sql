update pkghead set pkghead_version = '2.4.5' where pkghead_name = 'te';
