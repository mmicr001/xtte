update pkghead set pkghead_version = '2.3.1' where pkghead_name = 'te';
