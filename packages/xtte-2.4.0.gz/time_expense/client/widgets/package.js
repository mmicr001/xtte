enyo.depends(
  "parameter.js",
  "picker.js",
  "project.js"
);