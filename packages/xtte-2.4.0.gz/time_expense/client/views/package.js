enyo.depends(
  "list.js",
  "list_relations.js",
  "list_relations_editor_box.js",
  "documents_box.js",
  "workspace.js"
);