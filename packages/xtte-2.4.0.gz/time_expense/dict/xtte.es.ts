<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>ARAging</name>
    <message>
        <source></source>
        <translation></translation>
    </message>
</context>
<context>
    <name>PurchaseOrder</name>
    <message>
        <source></source>
        <translation></translation>
    </message>
</context>
<context>
    <name>configureCRM</name>
    <message>
        <source>Project Labor And Overhead:</source>
        <translation type="unfinished">Mano de obra y gastos generales del Proyecto:</translation>
    </message>
</context>
<context>
    <name>dspTimeExpenseHistory</name>
    <message>
        <source>Ext.</source>
        <translation type="unfinished">Tot.</translation>
    </message>
    <message>
        <source>Sheet #</source>
        <translation type="unfinished">Nº de Hoja</translation>
    </message>
    <message>
        <source>Work Date</source>
        <translation type="unfinished">Fecha laborable</translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished">Estado</translation>
    </message>
    <message>
        <source>Project Name</source>
        <translation type="unfinished">Nombre del Proyecto</translation>
    </message>
    <message>
        <source>Task Name</source>
        <translation type="unfinished">Nombre de Tarea</translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished">Descripción</translation>
    </message>
    <message>
        <source>Billable</source>
        <translation type="unfinished">Facturable</translation>
    </message>
    <message>
        <source>Expense</source>
        <translation type="unfinished">Gasto</translation>
    </message>
    <message>
        <source>Start Date</source>
        <translation type="unfinished">Fecha Inicial</translation>
    </message>
    <message>
        <source>End Date</source>
        <translation type="unfinished">Fecha Final</translation>
    </message>
    <message>
        <source>Project</source>
        <translation type="unfinished">Proyecto</translation>
    </message>
    <message>
        <source>Customer</source>
        <translation type="unfinished">Cliente</translation>
    </message>
    <message>
        <source>Customer Type</source>
        <translation type="unfinished">Tipo de Cliente</translation>
    </message>
    <message>
        <source>Customer Group</source>
        <translation type="unfinished">Grupo de Clientes</translation>
    </message>
    <message>
        <source>Item Group</source>
        <translation type="unfinished">Grupo de Productos</translation>
    </message>
    <message>
        <source>Class Code</source>
        <translation type="unfinished">Código de Clase</translation>
    </message>
    <message>
        <source>Class Code Pattern</source>
        <translation type="unfinished">Patrón de Código de Clase</translation>
    </message>
    <message>
        <source>Approved</source>
        <translation type="unfinished">Aprobado</translation>
    </message>
    <message>
        <source>Closed</source>
        <translation type="unfinished">Cerrado</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished">Cerrar</translation>
    </message>
    <message>
        <source>Query</source>
        <translation type="unfinished">Consulta</translation>
    </message>
    <message>
        <source>Print</source>
        <translation type="unfinished">Imprimir</translation>
    </message>
    <message>
        <source>Edit...</source>
        <translation type="unfinished">Editar...</translation>
    </message>
    <message>
        <source>View...</source>
        <translation type="unfinished">Ver...</translation>
    </message>
    <message>
        <source>Employee</source>
        <translation type="unfinished">Empleado</translation>
    </message>
    <message>
        <source>Time</source>
        <translation type="unfinished">Hora</translation>
    </message>
    <message>
        <source>Cust. Name</source>
        <translation type="unfinished">Nombre Clien.</translation>
    </message>
    <message>
        <source>Project#</source>
        <translation type="unfinished">Nº Proyecto</translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished">Tipo</translation>
    </message>
    <message>
        <source>Employee #</source>
        <translation type="unfinished">Nº de Empleado</translation>
    </message>
    <message>
        <source>Task#</source>
        <translation type="unfinished">Nº de Tarea</translation>
    </message>
    <message>
        <source>Qty</source>
        <translation type="unfinished">Cant.</translation>
    </message>
    <message>
        <source>Cust.#</source>
        <translation type="unfinished">Nº Clien.</translation>
    </message>
    <message>
        <source>PO</source>
        <translation type="unfinished">OC</translation>
    </message>
    <message>
        <source>Item</source>
        <translation type="unfinished">Producto</translation>
    </message>
    <message>
        <source>Employee Group</source>
        <translation type="unfinished">Grupo del Empleado</translation>
    </message>
    <message>
        <source>Customer Type Pattern</source>
        <translation type="unfinished">Patrón de Tipo de Cliente</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished">Abrir</translation>
    </message>
    <message>
        <source>Worksheet History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Worksheet Items</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>employee</name>
    <message>
        <source>Contractor</source>
        <translation type="unfinished">Contratador</translation>
    </message>
</context>
<context>
    <name>initMenu</name>
    <message>
        <source>Worksheets...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Worksheet History</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>item</name>
    <message>
        <source>Can not save item</source>
        <translation type="unfinished">No se puede guardar producto</translation>
    </message>
    <message>
        <source>You must select a Ledger Account or an expense account for Project Expense Items.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>project</name>
    <message>
        <source>Invalid Date</source>
        <translation type="unfinished">Fecha no válida</translation>
    </message>
    <message>
        <source>You must enter a valid Due Date</source>
        <translation type="unfinished">Debe proporcionar una Fecha Límite válida.</translation>
    </message>
    <message>
        <source>Gantt...</source>
        <translation type="unfinished">Gantt...</translation>
    </message>
    <message>
        <source>Billing</source>
        <translation type="unfinished">Facturación</translation>
    </message>
</context>
<context>
    <name>projectGantt</name>
    <message>
        <source>Ctrl+W</source>
        <translation type="unfinished">Ctrl+W</translation>
    </message>
    <message>
        <source>Project Gantt</source>
        <translation type="unfinished">Proyecto Gantt</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished">Cerrar</translation>
    </message>
</context>
<context>
    <name>task</name>
    <message>
        <source>Billing</source>
        <translation type="unfinished">Cobro</translation>
    </message>
</context>
<context>
    <name>tebilling</name>
    <message>
        <source>Use specified billing rate</source>
        <translation type="unfinished">Usar la tarifa de cobro especificada</translation>
    </message>
    <message>
        <source>Rate:</source>
        <translation type="unfinished">Tarifa:</translation>
    </message>
    <message>
        <source>Use Specified item</source>
        <translation type="unfinished">Usar producto Especificado</translation>
    </message>
    <message>
        <source>Billing</source>
        <translation type="unfinished">Cobro</translation>
    </message>
</context>
<context>
    <name>tecustomer</name>
    <message>
        <source>Billing</source>
        <translation type="unfinished">Facturación</translation>
    </message>
    <message>
        <source>Use specified billing rate</source>
        <translation type="unfinished">Usar la tarifa de facturación especificada</translation>
    </message>
    <message>
        <source>Rate:</source>
        <translation type="unfinished">Tarifa:</translation>
    </message>
</context>
<context>
    <name>teexpense</name>
    <message>
        <source>Account</source>
        <translation type="unfinished">Cuenta</translation>
    </message>
    <message>
        <source>Expense Category</source>
        <translation type="unfinished">Categorías de Gastos</translation>
    </message>
    <message>
        <source>Expense Item Setup</source>
        <translation type="unfinished">Preparación de Elemento de Gasto</translation>
    </message>
    <message>
        <source>Allow use as Expense Item on Projects</source>
        <translation type="unfinished">Permitir el empleo como Elemento de Gasto en Proyectos</translation>
    </message>
</context>
<context>
    <name>timeExpenseSheet</name>
    <message>
        <source>Line #</source>
        <translation type="unfinished">Nº de Línea</translation>
    </message>
    <message>
        <source>Documents</source>
        <translation type="unfinished">Documentos</translation>
    </message>
    <message>
        <source>Sheet Date</source>
        <translation type="unfinished">Fecha de la Hoja</translation>
    </message>
    <message>
        <source>Work Date</source>
        <translation type="unfinished">Fecha laborable</translation>
    </message>
    <message>
        <source>Total Cost</source>
        <translation type="unfinished">Costo Total</translation>
    </message>
    <message>
        <source>Project#</source>
        <translation type="unfinished">Nº Proyecto</translation>
    </message>
    <message>
        <source>Project Name</source>
        <translation type="unfinished">Nombre del Proyecto</translation>
    </message>
    <message>
        <source>Task#</source>
        <translation type="unfinished">Nº de Tarea</translation>
    </message>
    <message>
        <source>Task Name</source>
        <translation type="unfinished">Nombre de Tarea</translation>
    </message>
    <message>
        <source>Cust.#</source>
        <translation type="unfinished">Nº Clien.</translation>
    </message>
    <message>
        <source>Cust. Name</source>
        <translation type="unfinished">Nombre Clien.</translation>
    </message>
    <message>
        <source>PO</source>
        <translation type="unfinished">OC</translation>
    </message>
    <message>
        <source>Item</source>
        <translation type="unfinished">Producto</translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished">Descripción</translation>
    </message>
    <message>
        <source>Billable</source>
        <translation type="unfinished">Facturable</translation>
    </message>
    <message>
        <source>Rate</source>
        <translation type="unfinished">Tarifa</translation>
    </message>
    <message>
        <source>Extended</source>
        <translation type="unfinished">Extendido</translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished">Tipo</translation>
    </message>
    <message>
        <source>Edit...</source>
        <translation type="unfinished">Editar...</translation>
    </message>
    <message>
        <source>View...</source>
        <translation type="unfinished">Ver...</translation>
    </message>
    <message>
        <source>Delete...</source>
        <translation type="unfinished">Eliminar...</translation>
    </message>
    <message>
        <source>Are you sure you want to delete this line?</source>
        <translation type="unfinished">¿Está seguro que desea eliminar esta línea?</translation>
    </message>
    <message>
        <source>Employee Required</source>
        <translation type="unfinished">Se requiere Empleado</translation>
    </message>
    <message>
        <source>Site Required</source>
        <translation type="unfinished">Se requiere Centro</translation>
    </message>
    <message>
        <source>Week Ending Date Required</source>
        <translation type="unfinished">Se requiere Fecha de Finalización de Semana</translation>
    </message>
    <message>
        <source>Time</source>
        <translation type="unfinished">Hora</translation>
    </message>
    <message>
        <source>Expense</source>
        <translation type="unfinished">Gasto</translation>
    </message>
    <message>
        <source>Hours</source>
        <translation type="unfinished">Horas</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <source>Approved</source>
        <translation type="unfinished">Aprobado</translation>
    </message>
    <message>
        <source>Closed</source>
        <translation type="unfinished">Cerrado</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished">Abrir</translation>
    </message>
    <message>
        <source>Sheet #:</source>
        <translation type="unfinished">Nº de Hoja:</translation>
    </message>
    <message>
        <source>S&amp;heet</source>
        <translation type="unfinished">&amp;Hoja</translation>
    </message>
    <message>
        <source>Week of Date:</source>
        <translation type="unfinished">Semana de la Fecha:</translation>
    </message>
    <message>
        <source>Site:</source>
        <translation type="unfinished">Centro:</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation type="unfinished">Nuevo</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation type="unfinished">Editar</translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation type="unfinished">Ver</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <source>Notes</source>
        <translation type="unfinished">Notas</translation>
    </message>
    <message>
        <source>Print on Save</source>
        <translation type="unfinished">Imprimir al Guardar</translation>
    </message>
    <message>
        <source>...</source>
        <translation type="unfinished">...</translation>
    </message>
    <message>
        <source>Employee:</source>
        <translation type="unfinished">Empleado:</translation>
    </message>
    <message>
        <source>timeExpenseSheet.js exception: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>set exception: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>populateMenu exception: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>deleteItem exception: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>newItem exception: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>editItem exception: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>viewItem exception: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>openItem exception: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>accepted exception: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Worksheet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>handleNewButton exception: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>populate exception: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hourly Cost</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>fillList exception: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>printSheet exception: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete Worksheet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;Are you sure you want to cancel this Worksheet and discard all your changes?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>close exception: </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>timeExpenseSheetItem</name>
    <message>
        <source>Prev</source>
        <translation type="unfinished">Prev.</translation>
    </message>
    <message>
        <source>Next</source>
        <translation type="unfinished">Siguiente</translation>
    </message>
    <message>
        <source>Default</source>
        <translation type="unfinished">predeterminado</translation>
    </message>
    <message>
        <source>task</source>
        <translation type="unfinished">Tarea</translation>
    </message>
    <message>
        <source>&lt;p&gt;Would you like to update the existing rate?</source>
        <translation type="unfinished">¿Desea actualizar la tarifa existente?</translation>
    </message>
    <message>
        <source>New</source>
        <translation type="unfinished">Nuevo</translation>
    </message>
    <message>
        <source>Work Date Required</source>
        <translation type="unfinished">Se Requiere una Fecha Laborable</translation>
    </message>
    <message>
        <source>Project Required</source>
        <translation type="unfinished">Se requiere un Proyecto</translation>
    </message>
    <message>
        <source>Item Required</source>
        <translation type="unfinished">Se precisa Producto</translation>
    </message>
    <message>
        <source>Task Required</source>
        <translation type="unfinished">Se Requiere una Tarea</translation>
    </message>
    <message>
        <source>Billing of negative amounts is not supported</source>
        <translation type="unfinished">No se soporta la facturación de cantidades negativas</translation>
    </message>
    <message>
        <source>Processing Error</source>
        <translation type="unfinished">Error al procesar</translation>
    </message>
    <message>
        <source>Hours:</source>
        <translation type="unfinished">Horas:</translation>
    </message>
    <message>
        <source>Rate:</source>
        <translation type="unfinished">Tarifa:</translation>
    </message>
    <message>
        <source>Time</source>
        <translation type="unfinished">Hora</translation>
    </message>
    <message>
        <source>Qty:</source>
        <translation type="unfinished">Cant.:</translation>
    </message>
    <message>
        <source>Expense</source>
        <translation type="unfinished">Gasto</translation>
    </message>
    <message>
        <source>Unit Cost:</source>
        <translation type="unfinished">Costo Unitario:</translation>
    </message>
    <message>
        <source>Unsaved Changed</source>
        <translation type="unfinished">Cambios no guardados</translation>
    </message>
    <message>
        <source>  Cust. PO#:</source>
        <translation type="unfinished">Nº O/C Clien.:</translation>
    </message>
    <message>
        <source>Total:</source>
        <translation type="unfinished">Total:</translation>
    </message>
    <message>
        <source>Employee:</source>
        <translation type="unfinished">Empleado:</translation>
    </message>
    <message>
        <source>Billable</source>
        <translation type="unfinished">Facturable</translation>
    </message>
    <message>
        <source>timedtl_rate</source>
        <translation type="unfinished">timedtl_rate</translation>
    </message>
    <message>
        <source>Prepaid (not reimbursable)</source>
        <translation type="unfinished">Prepagado (no reembolsable)</translation>
    </message>
    <message>
        <source>Week of:</source>
        <translation type="unfinished">Semana de:</translation>
    </message>
    <message>
        <source>Work Date:</source>
        <translation type="unfinished">Fecha laborable:</translation>
    </message>
    <message>
        <source>Project #:</source>
        <translation type="unfinished">Nº de Proyecto:</translation>
    </message>
    <message>
        <source>Task:</source>
        <translation type="unfinished">Tarea:</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation type="unfinished">Tipo:</translation>
    </message>
    <message>
        <source>Summary</source>
        <translation type="unfinished">Resumen</translation>
    </message>
    <message>
        <source>Task</source>
        <translation type="unfinished">Tarea</translation>
    </message>
    <message>
        <source>Planned Hours:</source>
        <translation type="unfinished">Horas Previsionales:</translation>
    </message>
    <message>
        <source>Planned Expense:</source>
        <translation type="unfinished">Gasto Previsional:</translation>
    </message>
    <message>
        <source>Actual Hours:</source>
        <translation type="unfinished">Horas Reales:</translation>
    </message>
    <message>
        <source>Actual Expense:</source>
        <translation type="unfinished">Gasto Reale:</translation>
    </message>
    <message>
        <source>Employee</source>
        <translation type="unfinished">Empleado</translation>
    </message>
    <message>
        <source>Day Total:</source>
        <translation type="unfinished">Total Día:</translation>
    </message>
    <message>
        <source>Hours</source>
        <translation type="unfinished">Horas</translation>
    </message>
    <message>
        <source>Notes</source>
        <translation type="unfinished">Notas</translation>
    </message>
    <message>
        <source>Line #:</source>
        <translation type="unfinished">Nº Línea:</translation>
    </message>
    <message>
        <source>No task found. A default task will be added</source>
        <translation type="unfinished">No se ha hallado tarea. Se añadirá una tarea predeterminada</translation>
    </message>
    <message>
        <source>&lt;p&gt;You have made some changes which have not yet been saved!
Would you like to save them now?</source>
        <translation type="unfinished">¡Ha realizado algunos cambios que no se han guardado todavía! ¿Desea guardarlos ahora?</translation>
    </message>
    <message>
        <source>Update Rate?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The system only supports vouchering positive expense quantities and amounts.  Do you want to save anyway?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The Employee is not a Vendor, this expense cannot be vouchered.  Do you want to continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;You have made some changes which have not yet been saved!&lt;/p&gt;&lt;p&gt;Would you like to save them now?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Worksheet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Worksheet:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hourly Cost:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total Cost:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Worksheet Total:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>timeExpenseSheets</name>
    <message>
        <source>Sheet#</source>
        <translation type="unfinished">Nº de Hoja</translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished">Fecha</translation>
    </message>
    <message>
        <source>Employee</source>
        <translation type="unfinished">Empleado</translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished">Estado</translation>
    </message>
    <message>
        <source>Invoiced</source>
        <translation type="unfinished">Facturado</translation>
    </message>
    <message>
        <source>Vouchered</source>
        <translation type="unfinished">Con justificante</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished">Eliminar</translation>
    </message>
    <message>
        <source>Approve</source>
        <translation type="unfinished">Aprobar</translation>
    </message>
    <message>
        <source>Unapprove</source>
        <translation type="unfinished">No aprobar</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished">Cerrar</translation>
    </message>
    <message>
        <source>Invoice</source>
        <translation type="unfinished">Factura</translation>
    </message>
    <message>
        <source>Voucher</source>
        <translation type="unfinished">Justificante</translation>
    </message>
    <message>
        <source>Post Time</source>
        <translation type="unfinished">Hora de Apunte</translation>
    </message>
    <message>
        <source>Setup Error</source>
        <translation type="unfinished">Error de Preparación</translation>
    </message>
    <message>
        <source>No Labor and Overhead Account defined in CRM Setup.</source>
        <translation type="unfinished">No se ha definido Cuenta de Gastos Generales y Mano de Obra en los Ajustes de CRM.</translation>
    </message>
    <message>
        <source>Post Time Sheet for </source>
        <translation type="unfinished">Registrar Hoja de Tiempo para</translation>
    </message>
    <message>
        <source> to Project</source>
        <translation type="unfinished">al Proyecto</translation>
    </message>
    <message>
        <source>Approved</source>
        <translation type="unfinished">Aprobado</translation>
    </message>
    <message>
        <source>Closed</source>
        <translation type="unfinished">Cerrado</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished">Abrir</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="unfinished">Sí</translation>
    </message>
    <message>
        <source>No</source>
        <translation type="unfinished">No</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation type="unfinished">N/D</translation>
    </message>
    <message>
        <source>It appears that your current user isn&apos;t an active employee.</source>
        <translation type="unfinished">Parece que su usuario actual no es un empleado activo.</translation>
    </message>
    <message>
        <source>Permissions Error</source>
        <translation type="unfinished">Error de Permisos</translation>
    </message>
    <message>
        <source>Earliest</source>
        <translation type="unfinished">Primero</translation>
    </message>
    <message>
        <source>Latest</source>
        <translation type="unfinished">Último</translation>
    </message>
    <message>
        <source>Employees</source>
        <translation type="unfinished">Empleados</translation>
    </message>
    <message>
        <source>Selected:</source>
        <translation type="unfinished">Seleccionado:</translation>
    </message>
    <message>
        <source>Week of</source>
        <translation type="unfinished">Semana de</translation>
    </message>
    <message>
        <source>When Processing:</source>
        <translation type="unfinished">Al procesar:</translation>
    </message>
    <message>
        <source>New</source>
        <translation type="unfinished">Nuevo</translation>
    </message>
    <message>
        <source>Ctrl+N</source>
        <translation type="unfinished">Ctrl+N</translation>
    </message>
    <message>
        <source>Ctrl+W</source>
        <translation type="unfinished">Ctrl+W</translation>
    </message>
    <message>
        <source>Process</source>
        <translation type="unfinished">Procesar</translation>
    </message>
    <message>
        <source>Process Approved</source>
        <translation type="unfinished">Procesar Aprobados</translation>
    </message>
    <message>
        <source>Query</source>
        <translation type="unfinished">Consulta</translation>
    </message>
    <message>
        <source>Ctrl+R</source>
        <translation type="unfinished">Ctrl+R</translation>
    </message>
    <message>
        <source>Ctrl+P</source>
        <translation type="unfinished">Ctrl+P</translation>
    </message>
    <message>
        <source>Print</source>
        <translation type="unfinished">Imprimir</translation>
    </message>
    <message>
        <source>Posted</source>
        <translation type="unfinished">Apuntado</translation>
    </message>
    <message>
        <source>Edit...</source>
        <translation type="unfinished">Editar...</translation>
    </message>
    <message>
        <source>View...</source>
        <translation type="unfinished">Ver...</translation>
    </message>
    <message>
        <source>All</source>
        <translation type="unfinished">Todos</translation>
    </message>
    <message>
        <source>Approve All</source>
        <translation type="unfinished">Aprobar Todo</translation>
    </message>
    <message>
        <source>To Invoice</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To Voucher</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This action can not be undone.  Are you sure you want to delete this Worksheet?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You do not have permissions to maintain Worksheet entries</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Worksheets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Notes</source>
        <translation type="unfinished">Notas</translation>
    </message>
    <message>
        <source>Hours</source>
        <translation type="unfinished">Horas</translation>
    </message>
    <message>
        <source>Reopen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure you want to close this Worksheet?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure you want to reopen this Worksheet?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Direct Reports</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>xtte</name>
    <message>
        <source>Database Error</source>
        <translation type="unfinished">Error en la Base de Datos</translation>
    </message>
</context>
</TS>
