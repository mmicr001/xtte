<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>ARAging</name>
    <message>
        <source></source>
        <translation></translation>
    </message>
</context>
<context>
    <name>PurchaseOrder</name>
    <message>
        <source></source>
        <translation></translation>
    </message>
</context>
<context>
    <name>configureCRM</name>
    <message>
        <source>Project Labor And Overhead:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dspTimeExpenseHistory</name>
    <message>
        <source>Start Date</source>
        <translation type="unfinished">Data de Início</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished">Aberto</translation>
    </message>
    <message>
        <source>Print</source>
        <translation type="unfinished">Imprimir</translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished">Tipo</translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished">Posição</translation>
    </message>
    <message>
        <source>View...</source>
        <translation type="unfinished">Visualizar...</translation>
    </message>
    <message>
        <source>Closed</source>
        <translation type="unfinished">Fechado</translation>
    </message>
    <message>
        <source>Time</source>
        <translation type="unfinished">Horas</translation>
    </message>
    <message>
        <source>Class Code</source>
        <translation type="unfinished">Código de Classe</translation>
    </message>
    <message>
        <source>Edit...</source>
        <translation type="unfinished">Editar...</translation>
    </message>
    <message>
        <source>Expense</source>
        <translation type="unfinished">Despesa</translation>
    </message>
    <message>
        <source>Item</source>
        <translation type="unfinished">Item</translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished">Descrição</translation>
    </message>
    <message>
        <source>Qty</source>
        <translation type="unfinished">Qtde</translation>
    </message>
    <message>
        <source>Query</source>
        <translation type="unfinished">Consulta</translation>
    </message>
    <message>
        <source>Customer</source>
        <translation type="unfinished">Cliente</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished">Fechar</translation>
    </message>
    <message>
        <source>Sheet #</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Employee #</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Work Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Project#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Project Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Task#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Task Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cust.#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cust. Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Billable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ext.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>End Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Employee</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Employee Group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Customer Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Customer Type Pattern</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Customer Group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Item Group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Class Code Pattern</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Approved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Worksheet History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Worksheet Items</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>employee</name>
    <message>
        <source>Contractor</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>initMenu</name>
    <message>
        <source>Worksheets...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Worksheet History</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>item</name>
    <message>
        <source>Can not save item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You must select a Ledger Account or an expense account for Project Expense Items.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>project</name>
    <message>
        <source>Billing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gantt...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You must enter a valid Due Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid Date</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>projectGantt</name>
    <message>
        <source>Close</source>
        <translation type="unfinished">Fechar</translation>
    </message>
    <message>
        <source>Project Gantt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+W</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>task</name>
    <message>
        <source>Billing</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>tebilling</name>
    <message>
        <source>Billing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use specified billing rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use Specified item</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>tecustomer</name>
    <message>
        <source>Billing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use specified billing rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rate:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>teexpense</name>
    <message>
        <source>Account</source>
        <translation type="unfinished">Conta</translation>
    </message>
    <message>
        <source>Expense Item Setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Allow use as Expense Item on Projects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Expense Category</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>timeExpenseSheet</name>
    <message>
        <source>Notes</source>
        <translation type="unfinished">Notas</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished">Erro</translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation type="unfinished">&amp;Visualizar</translation>
    </message>
    <message>
        <source>Time</source>
        <translation type="unfinished">Horas</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished">Aberto</translation>
    </message>
    <message>
        <source>...</source>
        <translation type="unfinished">...</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation type="unfinished">&amp;Editar</translation>
    </message>
    <message>
        <source>Closed</source>
        <translation type="unfinished">Fechado</translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished">Tipo</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation type="unfinished">&amp;Novo</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation type="unfinished">&amp;Apagar</translation>
    </message>
    <message>
        <source>Extended</source>
        <translation type="unfinished">Prolongado</translation>
    </message>
    <message>
        <source>Expense</source>
        <translation type="unfinished">Despesa</translation>
    </message>
    <message>
        <source>View...</source>
        <translation type="unfinished">Visualizar...</translation>
    </message>
    <message>
        <source>Edit...</source>
        <translation type="unfinished">Editar...</translation>
    </message>
    <message>
        <source>Item</source>
        <translation type="unfinished">Item</translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished">Descrição</translation>
    </message>
    <message>
        <source>Delete...</source>
        <translation type="unfinished">Apagar...</translation>
    </message>
    <message>
        <source>Line #</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sheet Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Work Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Project#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Project Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Task#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Task Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cust.#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cust. Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hours</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Billable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>timeExpenseSheet.js exception: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>set exception: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>populateMenu exception: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure you want to delete this line?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>deleteItem exception: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>newItem exception: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>editItem exception: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>viewItem exception: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>openItem exception: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>accepted exception: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Employee Required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Site Required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Week Ending Date Required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Worksheet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>handleNewButton exception: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>populate exception: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hourly Cost</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total Cost</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>fillList exception: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Approved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>printSheet exception: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete Worksheet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;Are you sure you want to cancel this Worksheet and discard all your changes?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>close exception: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sheet #:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>S&amp;heet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Week of Date:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Site:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Employee:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Documents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Print on Save</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>timeExpenseSheetItem</name>
    <message>
        <source>Expense</source>
        <translation type="unfinished">Despesa</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation type="unfinished">Tipo:</translation>
    </message>
    <message>
        <source>Default</source>
        <translation type="unfinished">Predefinido</translation>
    </message>
    <message>
        <source>Time</source>
        <translation type="unfinished">Horas</translation>
    </message>
    <message>
        <source>Notes</source>
        <translation type="unfinished">Notas</translation>
    </message>
    <message>
        <source>Unit Cost:</source>
        <translation type="unfinished">Unidade Custo:</translation>
    </message>
    <message>
        <source>Line #:</source>
        <translation type="unfinished">Linha #:</translation>
    </message>
    <message>
        <source>Total:</source>
        <translation type="unfinished">Total:</translation>
    </message>
    <message>
        <source>Total Cost:</source>
        <translation type="unfinished">Total de Custo:</translation>
    </message>
    <message>
        <source>Prev</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No task found. A default task will be added</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>task</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Update Rate?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;Would you like to update the existing rate?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Work Date Required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Project Required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Item Required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Task Required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Billing of negative amounts is not supported</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Processing Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The system only supports vouchering positive expense quantities and amounts.  Do you want to save anyway?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hours:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qty:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The Employee is not a Vendor, this expense cannot be vouchered.  Do you want to continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unsaved Changed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;You have made some changes which have not yet been saved!&lt;/p&gt;&lt;p&gt;Would you like to save them now?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;You have made some changes which have not yet been saved!
Would you like to save them now?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Worksheet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Worksheet:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Week of:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Work Date:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Project #:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Task:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>  Cust. PO#:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Employee:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Billable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>timedtl_rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Prepaid (not reimbursable)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hourly Cost:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Summary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Task</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Planned Hours:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Planned Expense:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Actual Hours:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Actual Expense:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Employee</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Day Total:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Worksheet Total:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hours</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>timeExpenseSheets</name>
    <message>
        <source>Yes</source>
        <translation type="unfinished">Sim</translation>
    </message>
    <message>
        <source>Closed</source>
        <translation type="unfinished">Fechado</translation>
    </message>
    <message>
        <source>Query</source>
        <translation type="unfinished">Consulta</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation type="unfinished">N/A</translation>
    </message>
    <message>
        <source>Earliest</source>
        <translation type="unfinished">Mais Recente</translation>
    </message>
    <message>
        <source>Latest</source>
        <translation type="unfinished">Último</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished">Aberto</translation>
    </message>
    <message>
        <source>Posted</source>
        <translation type="unfinished">Afixado</translation>
    </message>
    <message>
        <source>Date</source>
        <translation type="unfinished">Data</translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="unfinished">Posição</translation>
    </message>
    <message>
        <source>View...</source>
        <translation type="unfinished">Visualizar...</translation>
    </message>
    <message>
        <source>Print</source>
        <translation type="unfinished">Imprimir</translation>
    </message>
    <message>
        <source>Edit...</source>
        <translation type="unfinished">Editar...</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished">Apagar</translation>
    </message>
    <message>
        <source>All</source>
        <translation type="unfinished">Tudo</translation>
    </message>
    <message>
        <source>Invoice</source>
        <translation type="unfinished">Factura</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="unfinished">Fechar</translation>
    </message>
    <message>
        <source>Voucher</source>
        <translation type="unfinished">Vale</translation>
    </message>
    <message>
        <source>Selected:</source>
        <translation type="unfinished">Selecionado:</translation>
    </message>
    <message>
        <source>Sheet#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Employee</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To Invoice</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To Voucher</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invoiced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vouchered</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Approve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unapprove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Post Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Setup Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No Labor and Overhead Account defined in CRM Setup.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Post Time Sheet for </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> to Project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This action can not be undone.  Are you sure you want to delete this Worksheet?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This action can not be undone. Are you sure you want to close this Worksheet?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Approved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>It appears that your current user isn&apos;t an active employee.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Permissions Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You do not have permissions to maintain Worksheet entries</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Worksheets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Employees</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Week of</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>When Processing:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Process</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Process Approved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Approve All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+R</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+P</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>xtte</name>
    <message>
        <source>Database Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
