UPDATE invchead
   SET invchead_gldistdate=NULL
 WHERE NOT invchead_posted;
