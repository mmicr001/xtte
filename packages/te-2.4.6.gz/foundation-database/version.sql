update pkghead set pkghead_version = '2.4.6' where pkghead_name = 'te';
