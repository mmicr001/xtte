update pkghead set pkghead_version = '2.4.7' where pkghead_name = 'te';
