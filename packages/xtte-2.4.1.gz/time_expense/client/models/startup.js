/*jshint indent:2, curly:true, eqeqeq:true, immed:true, latedef:true,
newcap:true, noarg:true, regexp:true, undef:true, strict:true, trailing:true,
white:true*/
/*global XT:true, XM:true, Backbone:true, _:true, console:true */

(function () {
  "use strict";

  XT.extensions.timeExpense.initStartup = function () {
    XT.cacheCollection("XM.expenseCategories", "XM.ExpenseCategoryCollection", "code");
    XT.cacheCollection("XM.siteRelations", "XM.SiteRelationCollection", "code");
  };

}());
