update pkghead set pkghead_version = '2.4.4' where pkghead_name = 'te';
